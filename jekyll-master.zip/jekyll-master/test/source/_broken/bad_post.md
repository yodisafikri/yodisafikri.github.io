---
bad yaml: [
---
Real content starts here
